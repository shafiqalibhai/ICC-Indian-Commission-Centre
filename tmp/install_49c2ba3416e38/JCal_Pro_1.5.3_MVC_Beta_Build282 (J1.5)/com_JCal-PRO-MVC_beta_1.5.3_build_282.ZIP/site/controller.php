<?php
  // JCal Admin Controller
  jimport('joomla.application.component.controller');
  
  class JCalProController extends JController {
      
  }
?>
