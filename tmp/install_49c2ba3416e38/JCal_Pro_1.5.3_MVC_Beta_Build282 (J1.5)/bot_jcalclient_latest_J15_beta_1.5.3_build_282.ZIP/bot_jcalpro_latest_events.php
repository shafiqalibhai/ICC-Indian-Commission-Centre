<?php
/*
 **********************************************
 JCal Pro Latest Events Plugin v1.5.0
 Copyright (c) 2007 Anything-Digital.com
 **********************************************
 JCal Pro is a fork of the existing Extcalendar component for Joomla!
 (com_extcal_0_9_2_RC4.zip from mamboguru.com).
 Extcal (http://sourceforge.net/projects/extcal) was renamed
 and adapted to become a Mambo/Joomla! component by
 Matthew Friedman, and further modified by David McKinnis
 (mamboguru.com) to repair some security holes.

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This header must not be removed. Additional contributions/changes
 may be added to this header as long as no information is deleted.
 **********************************************

 * Latest Events Plugin
 *
 * $Id: bot_jcalpro_latest_events.php 304 2008-06-17 15:44:04Z shumisha $
 *
 * Plugin for displaying upcoming events in connection with the JCal Pro
 * component. The component must be installed before this module will work.
 * There are some options for this plugin, which can be set in the
 * "Parameters" section of the plugin in Administration.
 *
 *
 * Once installed and published, include the following text in a
 * content item:
 *
 * {jcal_latest}X{/jcal_latest}
 *
 * Where "X" is the event category or categories you want displayed in the
 * content item. Use "0" or blank for events from all categories, "1" for
 * events from category 1, "1,2" for events from category 1 and 2, etc.

 **********************************************
 Get the latest version of JCal Pro at:
 http://dev.anything-digital.com//
 **********************************************
 */

defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.' );

$mainframe->registerEvent( 'onPrepareContent', 'plgJCalLatest' );

function plgJCalLatest( &$rowContent, &$params, $page=0 ) {

  // save content item params
  $contentParams = $params;
  // get plugin params
  $plugin =& JPluginHelper::getPlugin('content', 'bot_jcalpro_latest_events');
  $params = new JParameter($plugin->params);
  
  // Get Plugin info

  if (preg_match_all("#{jcal_latest}(\d+){/jcal_latest}#s", $rowContent->text, $matches, PREG_PATTERN_ORDER) > 0) {
    foreach ($matches[0] as $match) {
      $_category_ = preg_replace("/{.+?}/", "", $match);
      $html = '';
      if( is_readable(JPATH_ROOT. DS. 'modules'.DS.'mod_jcalclient_latest_J15'.DS.'mod_jcalclient_latest_J15.php') ) {
        ob_start();
        $params->set('categories',$_category_);
        include( JPATH_ROOT. DS . 'modules'.DS.'mod_jcalclient_latest_J15'.DS.'mod_jcalclient_latest_J15.php' );
        $html = ob_get_contents();
        ob_end_clean();
      }
      $rowContent->text = preg_replace( "#{jcal_latest}".$_category_."{/jcal_latest}#s", $html , $rowContent->text );
    }
  }
  
  //restore content item params
  $params = $contentParams;
}

?>
