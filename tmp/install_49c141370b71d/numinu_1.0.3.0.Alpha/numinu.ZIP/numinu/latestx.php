<?php
/**
* @version $Id: showcat.php 63 2007-04-17 21:23:17Z danialt $
* Fireboard Component
* @package Fireboard
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*
* Based on Joomlaboard Component
* @copyright (C) 2000 - 2004 TSMF / Jan de Graaff / All Rights Reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author TSMF & Jan de Graaff
**/
// Dont allow direct linking
defined ('_VALID_MOS') or die('Direct Access to this location is not allowed.');
$mainframe->addCustomHeadTag('<script type="text/javascript" src="' . JB_TMPLTURL . '/plugin/jtip/jquery.dimensions.js"></script>');
/*
$mainframe->addCustomHeadTag('<script type="text/javascript" src="' . JB_TMPLTURL . '/plugin/jtip/jquery.hoverIntent.js"></script>');
*/
$mainframe->addCustomHeadTag('<script type="text/javascript" src="' . JB_TMPLTURL . '/plugin/jtip/jquery.cluetip.js"></script>');
$mainframe->addCustomHeadTag('<script type="text/javascript" src="' . JB_TMPLTURL . '/plugin/jtip/demo.js"></script>');
$mainframe->addCustomHeadTag('<script type="text/javascript" src="' . JB_TMPLTURL . '/js/cube_common.js"></script>');
require_once (JB_ABSSOURCESPATH . 'fb_auth.php');
//resetting some things:
$lockedForum = 0;
$lockedTopic = 0;
$topicSticky = 0;
$ResultSet   = "";
if ($my->id > 0)
{
	$database->setQuery("SELECT gid FROM #__users WHERE id=$my->id");
	$group_id = $database->loadResult();
	$database->setQuery("SELECT id FROM #__fb_categories WHERE (pub_access<=$group_id)  ");
	$allowed_forums = $database->loadObjectList();
	foreach ($allowed_forums as $af)
	{
		if ($ResultSet == "")
		{
			$ResultSet = $af->id;
		}
		else
		{
			$ResultSet = $ResultSet . ',' . $af->id;
		}
	}
//$allowed_forums = explode (',',$ResultSet);
}
else
{
	$database->setQuery("SELECT id FROM #__fb_categories WHERE pub_access='0'");
	$allowed_forums = $database->loadObjectList();
	foreach ($allowed_forums as $af)
	{
		if ($ResultSet == "")
		{
			$ResultSet = $af->id;
		}
		else
		{
			$ResultSet = $ResultSet . ',' . $af->id;
		}
	}
}
//start the latest x
if ($sel == "0") {
    $querytime = ($prevCheck - 1800); //move 30 minutes back to compensate for expired sessions
}
else
{
    if ("" == $sel) {
        $sel = 999999999;
    } //take 999999999 hours as default
    //Time translation
    $back_time = $sel * 3600; //hours*(mins*secs)
    $querytime = time() - $back_time;
}
//$querytime = time() - 24*3600;
//get the db data with allowed forums and turn it into an array
$threads_per_page = $fbConfig['threads_per_page'];
/*//////////////// Start selecting messages, prepare them for threading, etc... /////////////////*/
$page             = (int)$page;
$page             = $page < 1 ? 1 : $page;
$offset           = ($page - 1) * $threads_per_page;
$row_count        = $page * $threads_per_page;
$database->setQuery("Select count(*) FROM #__fb_messages WHERE parent = '0' AND time >'$querytime' AND hold = '0' ");
$total = (int)$database->loadResult();
$database->setQuery("SELECT a. * ,   m.mesid, f.thread AS favthread, u.avatar , c.name AS catname, 
MAX( b.time )  AS lastpost FROM  #__fb_messages  AS a 
	 LEFT  JOIN #__fb_messages  AS b ON b.thread = a.thread  && b.hold=0
	 LEFT  JOIN #__fb_categories  AS c ON c.id = a.catid  
	 LEFT  JOIN #__fb_attachments AS m ON m.mesid = a.id
	 LEFT  JOIN #__fb_favorites AS f ON  f.thread = a.id && f.userid = $my->id
	 " .(($fbConfig['avatar_src'] == "cb")?"LEFT  JOIN #__comprofiler AS u ON u.user_id = a.userid":"LEFT  JOIN #__fb_users AS u ON u.userid = a.userid")."
	 WHERE a.parent =  '0'  
	 AND a.time >'$querytime'
	 AND b.catid IN ($ResultSet)
	 AND a.hold =  0 
	 GROUP  BY id ORDER  BY  lastpost DESC  
	 LIMIT $offset,$threads_per_page");
/*     if ($my->id == 68) {
           echo $database->getQuery();
     }*/
     
	 //check if $sel has a reasonable value and not a Unix timestamp:
	$since = false;
	if ($sel == "0")
	{
		$lastvisit = date(_DATETIME, $querytime);
		$since = true;
	}
 
foreach ($database->loadObjectList()as $message)
{
	$threadids[]                  = $message->id;
	$messages[$message->parent][] = $message;
	$last_reply[$message->id]     = $message;
	$hits[$message->id]           = $message->hits;
}
if (count($threadids) > 0)
{
	$idstr = @join("','", $threadids);
	$query = "SELECT a.id,a.parent,a.thread,a.catid,a.subject,a.name,a.time,a.topic_emoticon,a.locked,a.ordering,a.userid , a.moved,u.avatar FROM #__fb_messages AS a "
    .(($fbConfig['avatar_src'] == "cb")?"LEFT  JOIN #__comprofiler AS u ON u.user_id = a.userid":"LEFT  JOIN #__fb_users AS u ON u.userid = a.userid")
    ." WHERE a.thread IN ('$idstr') AND a.id NOT IN ('$idstr') and a.hold=0"
    ;
    $database->setQuery($query);
	foreach ($database->loadObjectList()as $message)
	{
		$messages[$message->parent][] = $message;
		$thread_counts[$message->thread]++;
		$last_reply[$message->thread] = $last_reply[$message->thread]->time < $message->time ? $message : $last_reply[$message->thread];
	}
}
?>
<?php include (JB_ABSTMPLTPATH . '/tab_list.php'); ?>
<!-- B: List Actions -->
	<div class="fb_list_actions"><table border="0" cellpadding="0" cellspacing="0" width="100%">
                                  <tr>
                                    <td   class="fb_list_actions_info_all" width="100%">
    <strong><?php echo $total; ?></strong> <?php // TO-DO Lang ?>Discussions
								</td>
                                
                                    <td class="fb_list_times_all">
									
									<?php  $show_list_time = mosGetParam($_REQUEST, 'sel', '');  ?>
									<select class="inputboxusl" onchange="document.location.href=this.options[this.selectedIndex].value;" size="1" name="select" style = "margin:0; padding:0; width:100px;">
									 <option <?php if ($show_list_time =='999999999') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest'); ?>"><?php echo 'All Time' ; ?></option>
									  <option <?php if ($show_list_time =='0') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=0'); ?>"><?php echo _SHOW_LASTVISIT; ?></option>
									  <option <?php if ($show_list_time =='4') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=4'); ?>"><?php echo _SHOW_4_HOURS; ?></option>
									  <option <?php if ($show_list_time =='8') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=8'); ?>"><?php echo _SHOW_8_HOURS; ?></option>
									  <option <?php if ($show_list_time =='12') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=12'); ?>"><?php echo _SHOW_12_HOURS; ?></option>
									  <option <?php if ($show_list_time =='24') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=24'); ?>"><?php echo _SHOW_24_HOURS; ?></option>
									  <option <?php if ($show_list_time =='48') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=48'); ?>"><?php echo _SHOW_48_HOURS; ?></option>
									  <option <?php if ($show_list_time =='168') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=168'); ?>"><?php echo _SHOW_WEEK; ?></option>
									  <option <?php if ($show_list_time =='720') {?> selected="selected"  <?php }?> value="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=latest&amp;do=show&amp;sel=720'); ?>"><?php echo 'Month'; ?></option>
									</select>
									
                                  </td>
                                    <td class="fb_list_jump_all">
                                  
                                    <?php if ($fbConfig['enableForumJump'])
 									 require_once (JB_ABSSOURCESPATH . 'fb_forumjump.php');
 									 ?>
                                   
                                   </td>
                                   
                                   <td class="fb_list_pages_all" nowrap="nowrap">
								
                                
								<?php
                                //pagination 1
								if (count($messages[0]) > 0)
								{
									
									echo _PAGE;
									if (($page - 2) > 1)
									{
										echo '<a  class="fb_list_pages_link" href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=latest&amp;page=1') . '">1</a>';
										echo "...&nbsp;";
									}
									for ($i = ($page - 2) <= 0 ? 1 : ($page - 2); $i <= $page + 2 && $i <= ceil($total / $threads_per_page); $i++)
									{
										if ($page == $i)
										{
											echo "$i";
										}
										else
										{
											echo '<a  class="fb_list_pages_link" href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=latest&amp;page=' . $i) . '">' . $i . '</a>';
										}
									}
									if ($page + 2 < ceil($total / $threads_per_page))
									{
										echo "...&nbsp;";
										echo '<a  class="fb_list_pages_link" href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=latest&amp;page=' . ceil($total / $threads_per_page)) . '">' . ceil($total / $threads_per_page)
												 . '</a>';
									}
									
								}
								?>
                            
                                </td>
                                   
                                  </tr>
                                </table>
						
							
				</div>
  <!-- F: List Actions --> 
<?php  
if (count($threadids) > 0)
{             
				
				//get all readTopics in an array
				$readTopics                      = "";
				$database->setQuery("SELECT readtopics FROM #__fb_sessions WHERE userid=$my->id");
				$readTopics = $database->loadResult();
				if (count($readTopics) == 0)
				{
					$readTopics = "0";
				} //make sure at least something is in there..
				//make it into an array
				$read_topics = explode(',', $readTopics);
				if (file_exists(JB_ABSTMPLTPATH . '/flat.php'))
				{
					include (JB_ABSTMPLTPATH . '/flat.php');
				}
				else
				{
					include (JB_ABSPATH . '/template/default/flat.php');
				}
				?>
<!-- B: List Actions -->
	<div class="fb_list_actions">
     <span class="fb_list_actions_info" ><?php // TO-DO Lang ?>Total Thread:  <strong><?php echo $total; ?></strong></span>
								<?php
								
								//pagination 1
								if (count($messages[0]) > 0)
								{
									echo '<span   class="fb_list_pages" >';
									echo _PAGE;
									if (($page - 2) > 1)
									{
										echo '<a  class="fb_list_pages_link" href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=latest&amp;page=1') . '">1</a>';
										echo "...&nbsp;";
									}
									for ($i = ($page - 2) <= 0 ? 1 : ($page - 2); $i <= $page + 2 && $i <= ceil($total / $threads_per_page); $i++)
									{
										if ($page == $i)
										{
											echo "$i";
										}
										else
										{
											echo '<a  class="fb_list_pages_link" href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=latest&amp;page=' . $i) . '">' . $i . '</a>';
										}
									}
									if ($page + 2 < ceil($total / $threads_per_page))
									{
										echo "...&nbsp;";
										echo '<a  class="fb_list_pages_link" href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=;latest&amp;page=' . ceil($total / $threads_per_page)) . '">' . ceil($total / $threads_per_page)
												 . '</a>';
									}
									echo '</span>';
								}
								?>
	</div>
  <!-- F: List Actions -->  
<?php
}
?>
<div class="clr"></div>
<?php
  
	if ($fbConfig['showstats'] > 0)
    {
		//(JJ) BEGIN: STATS
		if (file_exists(JB_ABSTMPLTPATH . '/plugin/stats/stats.class.php')) {
			include_once (JB_ABSTMPLTPATH . '/plugin/stats/stats.class.php');
		}
		else {
			include_once (JB_ABSPATH . '/template/default/plugin/stats/stats.class.php');
		}
	
		if (file_exists(JB_ABSTMPLTPATH . '/plugin/stats/frontstats.php')) {
			include (JB_ABSTMPLTPATH . '/plugin/stats/frontstats.php');
		}
		else {
			include (JB_ABSPATH . '/template/default/plugin/stats/frontstats.php');
		}
	}
    //(JJ) FINISH: STATS
	
	if ($fbConfig['showWhoisOnline'] > 0)
    {
	
		//(JJ) BEGIN: WHOISONLINE
		if (file_exists(JB_ABSTMPLTPATH . '/plugin/who/whoisonline.php')) {
			include (JB_ABSTMPLTPATH . '/plugin/who/whoisonline.php');
		}
		else {
			include (JB_ABSPATH . '/template/default/plugin/who/whoisonline.php');
		}
		//(JJ) FINISH: WHOISONLINE
		
	}

?>