<?php
/**
* @version $Id: flat.php 63 2007-04-17 21:23:17Z danialt $
* Fireboard Component
* @package Fireboard
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*
* Based on Joomlaboard Component
* @copyright (C) 2000 - 2004 TSMF / Jan de Graaff / All Rights Reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author TSMF & Jan de Graaff
**/
// Dont allow direct linking
defined ('_VALID_MOS') or die('Direct Access to this location is not allowed.');
?>

<!-- B: FLAT LIST -->
<?php // topic emoticons
$topic_emoticons = array ();
$topic_emoticons[0] = JB_URLEMOTIONSPATH . 'default.gif';
$topic_emoticons[1] = JB_URLEMOTIONSPATH . 'exclam.gif';
$topic_emoticons[2] = JB_URLEMOTIONSPATH . 'question.gif';
$topic_emoticons[3] = JB_URLEMOTIONSPATH . 'arrow.gif';
$topic_emoticons[4] = JB_URLEMOTIONSPATH . 'love.gif';
$topic_emoticons[5] = JB_URLEMOTIONSPATH . 'grin.gif';
$topic_emoticons[6] = JB_URLEMOTIONSPATH . 'shock.gif';
$topic_emoticons[7] = JB_URLEMOTIONSPATH . 'smile.gif';
// url of current page that user will be returned to after login
if ($query_string = mosGetParam($_SERVER, 'QUERY_STRING', ''))
{
	$Breturn = 'index.php?' . $query_string;
}
else
{
	$Breturn = 'index.php';
}
$Breturn  = str_replace('&', '&amp;', $Breturn);
$tabclass = array
(
	"sectiontableentry1",
	"sectiontableentry2"
);
$st_count = 0;
if (count($messages[0]) > 0)
{
	foreach ($messages[0] as $leafa)
	{
		if ($leafa->ordering > 0)
		{
			$st_count++;
		}
	}
}
?>
<!-- B:Item Lists -->
<div class="clr"></div>
<div class="fb_list_topics">
			<?php
			if (FBTools::isModOrAdmin() || $is_moderator)
			{
			?>
				<form action = "index.php" method = "post" name = "fbBulkActionForm">
			<?php
			}
			?>
			<?php
			$k    = 0;
			$st_c = 0;
			foreach ($messages[0] as $leaf)
			{
				$k           = 1 - $k; //used for alternating colours
				//$leaf->subject = htmlspecialchars($leaf->subject);
				$leaf->name  = htmlspecialchars($leaf->name);
				$leaf->email = htmlspecialchars($leaf->email);
			?>
			<?php
				if ($st_c == 0 && $st_occured != 1 && $st_count != 0)
				{
				//$st_occured = 1;
			?>
			<?php
				}
				if ($st_c == $st_count && $st_occured != 1 && $st_count != 0)
				{
					$st_occured = 1;
					$k          = 0;
			?>
			<?php
				}
			?>
<!-- B:Item -->
<div class="fb_list_item fb_line_<?php echo $k;?><?php if ($fbConfig['showNew'] && $my->id != 0){if (($prevCheck < $last_reply[$leaf->id]->time) && !in_array($last_reply[$leaf->id]->thread, $read_topics)) {echo '_newtopic'; } } ?><?php if ($leaf->ordering != 0) {echo '_sticky';}?>  ">
  <ul class="fb_list_item_cover_<?php echo $k;?>">
  <li class="topic_r"> 
        <!-- Replies -->
        <span class="topic_replies">
        <strong><?php echo (int)$thread_counts[$leaf->id]; ?></strong>
        Replies  
        </span>
        <!-- /Replies -->
		<?php if ($my->id ) { ?>
			 <!--  Favourite   -->
			<?php if ($fbConfig['allowfavorites'] == 1){ ?>
			<span class="topic_favorite">
			<?php if ($leaf->favthread > 0){ echo $fbIcons['favoritestar'] ? '<img  src="' . JB_URLICONSPATH . '' . $fbIcons['favoritestar'] . '" border="0" alt="' . _FB_FAVORITE . '" />' : '<img class="favoritestar" src="' . JB_URLEMOTIONSPATH . 'favoritestar.gif"  alt="' . _FB_FAVORITE . '" title="' . _FB_FAVORITE . '" />'; } ?>
			</span>
			<?php } ?>
			<!-- /Favourite  -->
		<?php } ?>
  </li>
  
        
  
  <li class="topic_p">

        
        <!-- Emo -->
        <span class="topic_emo"><?php echo $leaf->topic_emoticon == 0 ? '<img src="' . JB_URLEMOTIONSPATH . 'default.gif" border="0"  alt="" />' : "<img src=\"" . $topic_emoticons[$leaf->topic_emoticon] . "\" alt=\"emo\" border=\"0\" />"; ?>
        </span>
        <!-- /Emo -->
        
        <!-- Title -->
        <span class="topic_title">
        <a href = "<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=view&amp;id='.$leaf->id.$viewstr.'&amp;catid='.$leaf->catid);?>"><?php echo stripslashes($leaf->subject); ?></a>
        </span>
        <!-- /Title -->
            
        <!-- New -->
        <?php if ($fbConfig['showNew'] && $my->id != 0) {
            if (($prevCheck < $last_reply[$leaf->id]->time) && !in_array($last_reply[$leaf->id]->thread, $read_topics)) {
                echo '<span class="topic_title_new"><sup><span class="fb_list_new">&nbsp;(' . $fbConfig['newChar'] . ")</span></sup></span>"; } 
                } ?>
        <!-- /New -->
 
        <!-- Pages -->
        <?php
        $totalMessages = $thread_counts[$leaf->id];
        if ($totalMessages > $fbConfig['messages_per_page'])
        { ?>
        <span class="topic_pages">
        <?php
            $threadPages = ceil($totalMessages / $fbConfig['messages_per_page']);
            echo ("<span class=\"fb_list_perpage\">[");
            echo _PAGE;
            echo '<a href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=view&amp;id=' . $leaf->id . $viewstr . '&amp;catid=' . $leaf->catid) . '">1</a>';
            if ($threadPages > 3)
            {
                echo ("...");
                $startPage = $threadPages - 2;
            }
            else
            {
                echo (",");
                $startPage = 2;
            }
            $noComma = true;
            for ($hopPage = $startPage; $hopPage <= $threadPages; $hopPage++)
            {
                if ($noComma)
                {
                    $noComma = false;
                }
                else
                {
                    echo (",");
                }
                echo '<a href="' . sefRelToAbs(JB_LIVEURLREL . '&amp;func=view&amp;id=' . $leaf->id . '&amp;catid=' . $leaf->catid . '&amp;limit=' . $fbConfig['messages_per_page'] . '&amp;limitstart=' . (($hopPage - 1) * $fbConfig['messages_per_page'])) . '">'
                         . $hopPage . '</a>';
            }
            echo ("]</span>"); ?>
        </span>
        <?php }?>
        <!-- /Pages -->
    
       
                        
       
        <span class="topic_block">&nbsp;</span>
        <!-- By -->
        <span class="topic_posted_time">
        <a href="<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=view&amp;id='.$leaf->id.$viewstr.'&amp;catid='.$leaf->catid);?>">Posted <?php echo time_since($leaf->time , time() + ($fbConfig['board_ofset'] * 3600)); ?> ago
       		 <span> <?php echo date(_DATETIME, $leaf->time); ?></span>
        </a> 
        </span>
        <span class="topic_by">
        <?php echo _GEN_BY; ?> <a  href = "<?php echo sefRelToAbs(FB_PROFILE_LINK_SUFFIX.''.$leaf->userid)?>"><?php echo $leaf->name; ?></a>
        </span>
        <!-- /By -->
        <?php if (strtolower($func) != 'showcat' ){ ?>
        <!-- Category -->
        <span class="topic_category">
        Category: <a href = "<?php echo sefRelToAbs(JB_LIVEURLREL.'&amp;func=showcat&amp;catid='.$leaf->catid);?>"><?php echo $leaf->catname ;?> </a>  
        </span>
        <!-- /Category -->
        <?php } ?>
        	<!-- Views -->
        <span class="topic_views"> 
        Views: <?php echo (int)$hits[$leaf->id]; ?>
        </span>
        <!-- /Views -->
        
       <?php if ($leaf->mesid > 0){ ?>
        <!-- Attachments -->
        <span class="topic_attach">
        <?php echo $fbIcons['topicattach'] ? '<img  src="' . JB_URLICONSPATH . '' . $fbIcons['topicattach'] . '" border="0" alt="' . _FB_ATTACH . '" />' : '<img  src="' . JB_URLEMOTIONSPATH . 'attachment.gif"  alt="' . _FB_ATTACH . '" title="' . _FB_ATTACH . '" />'; ?>
        </span>
        <!-- /Attachments -->
        <?php }?>
        
        
        <?php if ($leaf->locked != 0) {?>
        <!-- Locked -->
        <span class="topic_locked">
        <?php echo $fbIcons['topiclocked'] ? '<img src="' . JB_URLICONSPATH . '' . $fbIcons['topiclocked'] . '" border="0" alt="' . _GEN_LOCKED_TOPIC . '" />'  : '<img src="' . JB_URLEMOTIONSPATH . 'lock.gif"  alt="' . _GEN_LOCKED_TOPIC . '" title="' . _GEN_LOCKED_TOPIC . '" />';
        $topicLocked = 1; ?>
        </span>
        <!-- /Locked -->
        <?php } ?>
    
  </li>
 <?php //(JJ) AVATAR
                    if ($fbConfig['avatarOnCat'] > 0)
                    { ?>
  <li class="topic_a">
   <!-- Avatar -->
  <span class="topic_latest_post_avatar">
  <?php 
	   $javatar =  $last_reply[$leaf->id]->avatar; 
	   if ($javatar!='') {
		   if ($fbConfig['avatar_src'] == "cb") { ?>
		 <a href="<?php echo sefRelToAbs(''.FB_PROFILE_LINK_SUFFIX.''.$last_reply[$leaf->id]->userid.''); ?>">  <img class="fb_list_avatar" src="images/comprofiler/<?php echo $javatar ?>" alt="" /></a>
		   <?php }  else { ?>
           
           
		 <a href="<?php echo sefRelToAbs(''.FB_PROFILE_LINK_SUFFIX.''.$last_reply[$leaf->id]->userid.''); ?>">  
         <img class="fb_list_avatar" src="<?php if(!file_exists(FB_ABSUPLOADEDPATH . '/avatars/s_' . $javatar)) { ?><?php echo FB_LIVEUPLOADEDPATH.'/avatars/'.$javatar ?>" alt=""  /></a><?php } else { ?><?php echo FB_LIVEUPLOADEDPATH.'/avatars/s_'.$javatar ?>" alt=""  /></a><?php } ?>
			<?php 
			}  
		} else {  ?>
			<a href="<?php  echo sefRelToAbs(''.FB_PROFILE_LINK_SUFFIX.''.$last_reply[$leaf->id]->userid.''); ?>">  <img class="fb_list_avatar" src="<?php echo FB_LIVEUPLOADEDPATH.'/avatars/s_nophoto.jpg'; ?>" alt=""  /></a>
		<?php } ?>
  </span>
  <!-- /Avatar -->
  </li>
  <?php } ?>
  <li class="topic_l">
  
  
 
   		<!--  Sticky   -->
        <?php if ($leaf->ordering != 0) { ?>
        <span class="topic_sticky">
        <?php echo $fbIcons['topicsticky'] ? '<img  src="' . JB_URLICONSPATH . '' . $fbIcons['topicsticky'] . '" border="0" alt="' . _GEN_ISSTICKY . '" />': '<img class="stickyicon" src="' . JB_URLEMOTIONSPATH . 'pushpin.gif"  alt="' . _GEN_ISSTICKY . '" title="' . _GEN_ISSTICKY . '" />';
        $topicSticky = 1; ?>
        </span>
        <?php }?>
        <!--  /Sticky   -->
        
        <!-- Latest Post -->
        <span class="topic_latest_post">
        <a href = "<?php echo sefRelToAbs('index.php?option=com_fireboard&amp;Itemid='.$Itemid.'&amp;func=view&amp;catid='.$leaf->catid.'&amp;id='.$last_reply[$leaf->id]->id).'#'.$last_reply[$leaf->id]->id;?>">Latest Post</a> <?php echo _GEN_BY; ?> <a class="topic_latest_post_user" href="<?php echo sefRelToAbs(''.FB_PROFILE_LINK_SUFFIX.''.$last_reply[$leaf->id]->userid.''); ?>"><?php echo $last_reply[$leaf->id]->name; ?></a>
        </span>
        <!-- /Latest Post -->
        
        <!-- Latest Post Date -->
        <span class="topic_date">
        <a href="<?php echo sefRelToAbs('index.php?option=com_fireboard&amp;Itemid='.$Itemid.'&amp;func=view&amp;catid='.$leaf->catid.'&amp;id='.$last_reply[$leaf->id]->id).'#'.$last_reply[$leaf->id]->id;?>"><?php echo time_since($last_reply[$leaf->id]->time , time() + ($fbConfig['board_ofset'] * 3600)); ?> ago
        <span> <?php echo date(_DATETIME, $last_reply[$leaf->id]->time); ?></span>
        </a>
        </span>
        <!-- /Latest Post Date -->
        
        <?php if (FBTools::isModOrAdmin()) { ?>
        <span class="topic_checkbox">
            <input type = "checkbox" name = "fbDelete[<?php echo $leaf->id?>]" value = "1"/>
        </span>
        <?php } ?>
    
  </li>
</ul>
</div>
                <!-- F:Item -->
			<?php
				$st_c++;
			}
			?>

			<?php
			if (FBTools::isModOrAdmin() || $is_moderator)
			{
			?>
				<script type = "text/javascript">
					jQuery(document).ready(function()
					{
						jQuery('#fbBulkActions').change(function()
						{
							var myList = jQuery(this);
							if (jQuery(myList).val() == "bulkMove")
							{
								jQuery("#FB_AvailableForums").removeAttr('disabled');
							}
							else
							{
								jQuery("#FB_AvailableForums").attr('disabled', 'disabled');
							}
						});
					});
				</script>
				<select name = "do" id = "fbBulkActions" class = "inputbox fbs">
					<option value = "">&nbsp;</option>
					<option value = "bulkDel"><?php echo _FB_DELETE_SELECTED; ?></option>
					<option value = "bulkMove"><?php echo _FB_MOVE_SELECTED; ?></option>
				</select>
				<?php
				FBTools::showBulkActionCats();
				?>
			<input type = "submit" name = "fbBulkActionsGo" class = "fbs" value = "<?php echo _FB_GO ; ?>"/>
			<?php
			}
			?>
			<?php
			if (FBTools::isModOrAdmin() || $is_moderator)
			{
			?>
				<input type = "hidden" name = "Itemid" value = "<?php echo FB_FB_ITEMID;?>"/>
				<input type = "hidden" name = "option" value = "com_fireboard"/>
				<input type = "hidden" name = "func" value = "bulkactions"/>
				<input type = "hidden" name = "return" value = "<?php echo sefRelToAbs( $Breturn ); ?>"/>
				</form>
			<?php
			}
			?>
</div>
<div class="clr"></div>
<!-- F:Item Lists -->
<!-- F: FLAT LIST -->