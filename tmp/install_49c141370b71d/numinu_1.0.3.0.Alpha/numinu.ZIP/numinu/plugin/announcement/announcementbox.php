<?php
/**
* @version $Id: announcementbox.php 63 2007-04-17 21:23:17Z danialt $
* Fireboard Component
* @package Fireboard
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*
* Based on Joomlaboard Component
* @copyright (C) 2000 - 2004 TSMF / Jan de Graaff / All Rights Reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author TSMF & Jan de Graaff
**/
// Dont allow direct linking
defined ('_VALID_MOS') or die('Direct Access to this location is not allowed.');

function jb_get_ann($database, $fbConfig, $my_id)
{

$readlink = 'index.php?option=com_fireboard&amp;func=announcement&amp;do=read&amp;id=';
// BEGIN: BOX ANN
$database->setQuery("SELECT id,title,sdescription,description, created ,published,showdate" . "\n FROM #__fb_announcement  WHERE  published = 1 ORDER BY created DESC LIMIT 1");
$anns = $database->loadObjectList();
$ann = $anns[0];
$annID = $ann->id;
$anntitle = $ann->title;
$annsdescription = $ann->sdescription;
$anndescription = $ann->description;
$anncreated = $ann->created;
$annpublished = $ann->published;
$annshowdate = $ann->showdate;
$anncontent ='';
if ($annID > 0) {
$anncontent ='<span class="fb_ann_title">';
$anncontent .= $anntitle;
$anncontent .= '</span> ';
if ($annshowdate > 0) { 
$anncontent .='<small>';
$anncontent .= $anncreated; 
$anncontent .='</small>';
}
$anncontent .='';
$anncontent .= $annsdescription; 
 
if ($anndescription != "") {
$anncontent .='&nbsp;<a href = "';
$anncontent .= $readlink;
$anncontent .= $annID;
$anncontent .='">';
$anncontent .= _ANN_READMORE; 
$anncontent .='</a>';
}
$anncontent .='';
$anncontent .='';
}

 return $anncontent;
}
