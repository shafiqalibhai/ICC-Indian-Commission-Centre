<?php
/**
* @version $Id: profilebox.php 63 2007-04-17 21:23:17Z danialt $
* Fireboard Component
* @package Fireboard
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*
* Based on Joomlaboard Component
* @copyright (C) 2000 - 2004 TSMF / Jan de Graaff / All Rights Reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author TSMF & Jan de Graaff
**/
// Dont allow direct linking
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');
if (strtolower($func) != 'userlist' and strtolower($func) != 'fbprofile'){ 

if (strtolower($func) == '' ){ 
include (JB_ABSTMPLTPATH . '/plugin/announcement/announcementbox.php');
$fbANN = jb_get_ann($database,$fbConfig, $my->id);
?>

<table class="fb_top_area"  border="0" cellspacing="0" cellpadding="0" >
  <tr>
  <?php if ($fbANN) { ?>  <td ><div class="fb_top_area_ann"><?php echo $fbANN ;?></div></td> <?php }?>
   <?php if (mosCountModules('fb_1')) {?> <td class="fb_top_area_mod"><?php mosLoadModules('fb_1', -2); ?> </td><?php  }  ?>
  </tr>
</table>

<?php } ?>
<div class="clr"></div>



<?php } ?>