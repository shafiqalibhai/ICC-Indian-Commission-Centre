<?php
/**
* @version $Id: profilebox.php 63 2007-04-17 21:23:17Z danialt $
* Fireboard Component
* @package Fireboard
* @Copyright (C) 2006 - 2007 Best Of Joomla All rights reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @link http://www.bestofjoomla.com
*
* Based on Joomlaboard Component
* @copyright (C) 2000 - 2004 TSMF / Jan de Graaff / All Rights Reserved
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author TSMF & Jan de Graaff
**/
// Dont allow direct linking
defined('_VALID_MOS') or die('Direct Access to this location is not allowed.');
?>
<!-- B: Tab -->
<div id="fb_list_navcontainer">
<ul id="fb_list_navlist">
<li <?php if (strtolower($func) == '' || strtolower($func) == 'latest' ){ ?> id="fb_list_navlist_active" <?php }?> >
<a <?php if (strtolower($func) == '' || strtolower($func) == 'latest'  ){ ?> id="current" <?php }?>  href="<?php echo sefRelToAbs(JB_LIVEURLREL . '') ;?>"> 
<?php // TO-DO Lang ?> All Discussions</a> </li> 
<li <?php if (strtolower($func) == 'listcat' || strtolower($func) == 'showcat' ){ ?> id="fb_list_navlist_active" <?php }?> >
<a <?php if (strtolower($func) == 'listcat' || strtolower($func) == 'showcat' ){ ?> id="current" <?php }?>  href="<?php echo sefRelToAbs(JB_LIVEURLREL . '&amp;func=listcat') ;?>"><?php // TO-DO Lang ?>Categories</a> 
</li> 

</ul><?php echo getSearchBox() ;?>
</div>
<!-- F: Tab -->